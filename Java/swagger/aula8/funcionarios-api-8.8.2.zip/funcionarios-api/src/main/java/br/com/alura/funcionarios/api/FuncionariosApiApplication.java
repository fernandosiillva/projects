package br.com.alura.funcionarios.api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FuncionariosApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(FuncionariosApiApplication.class, args);
	}
}
